<html>
<head>
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<link href="external/lib/jquery-ui.css" rel="stylesheet">
	<meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Automated T.L.A</title>
    <link rel="stylesheet" type="text/css" href="css/demos.css" />
	<link rel="icon" href="css/icon.ico" type="image/x-icon">
    <script src="external/jquery/jquery-1.8.3.js"></script>
<SCRIPT TYPE="text/javascript">
	var message="Sorry, right-click has been disabled";
	function clickIE() {if (document.all) {(message);return false;}}
	function clickNS(e) {if
	(document.layers||(document.getElementById&&!document.all)) {
	if (e.which==2||e.which==3) {(message);return false;}}}
	if (document.layers)
	{document.captureEvents(Event.MOUSEDOWN);document.onmousedown=clickNS;}
	else{document.onmouseup=clickNS;document.oncontextmenu=clickIE;}
	document.oncontextmenu=new Function("return false")
</SCRIPT>
<SCRIPT>
	$(document).keydown(function (event) {
    if (event.keyCode == 123) { // Prevent F12
        return false;
    } else if (event.ctrlKey && event.shiftKey && event.keyCode == 73) { // Prevent Ctrl+Shift+I        
        return false;
    }
	});
</SCRIPT>
<style>
.tableFixHead { overflow-y: auto; height: 300px; }

table { border-collapse: collapse; width: auto; }
th, td { padding: 8px 12px; }
th { background:#eee; }
</style>
<style>
h3 {
    color: DarkSlateGray;
    font-family: Georgia, serif;
    font-size: 30px;

}

#myTable th {
    background-color: #1c99ff;
    color: white;
	height: 50px;
}
#myTable td {
    background-color: #f4f6ff;
    padding: 15px;
    text-align: center;
}
.button {
    background-color: DodgerBlue; /* Light Blue */
    border: none;
    color: white;
	border-radius: 30px;
	padding: 10px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    margin: 4px 2px;
    cursor: pointer;
	font-family: Georgia, serif;
	width: 100px;
}
.button4 {
	background-color: LightSeaGreen ;
	border-radius: 30px;
	font-size: 15px;
	padding: 10px;
    border: none;
    color: white;
	display: inline-block;
    text-align: center;
    text-decoration: none;
	font-family: Georgia, serif;
	cursor: pointer;
	width: 100px;
}
.select-items {
  position: absolute;
  background-color: DodgerBlue;
  top: 100%;
  left: 0;
  right: 0;
  z-index: 99;
  width: 200px;
  height: 80px;
  overflow: auto;
}
</style>
<style>
img:hover {
    opacity: 0.5;
    filter: alpha(opacity=75); /* For IE8 and earlier */
}
img {
    width: auto;
    height: auto;
}
</style>

</head>
<div>
    <img src="images/logo.main.png" alt="logo"/>
</div>
<body>
<div id="tabs">

	<ul>
		<li><a href="#tabs-1">T.L.A</a></li>
	</ul>
	
<div id="tabs-1">	
	
	<form action="" method="post">
		<table cellpadding="0" id="myTable">
<!--		<tr>
			<th>Select Mode</th>
		</tr>
			<tr>
				<td> <input type="radio" name="selection" value="TMEM" required> TMEM </td>
				<td> <input type="radio" name="selection" value="TQMR" required> TQMR </td>
				<td> <input type="radio" name="selection" value="TBGAUM" required> TBGA(UNMOLDED) </td>
				<td> <input type="radio" name="selection" value="TBGA" required> TBGA </td>
				<td> <input type="radio" name="selection" value="TQFN" required> TQFN </td>
			</tr>
-->			
		<tr>
			<th>LOT ID</th>
			<th>BIN 1</th>
			<th>REJECTS</th>
		</tr>
		<tr>
			<td><input type="text" size="15" name="LOTID" placeholder="LOT ID HERE" style="text-transform:uppercase" pattern="[1-9]{1}[0-9]{9}" required></td>
			<td><input type="text" size="15" name="BINID" placeholder="BIN 1" onkeypress="validate(event)" required></td>
			<td><input type="text" size="15" name="REJECTS" placeholder="REJECTS" onkeypress="validate(event)" required></td>
		</tr>
		<tr>
			<td></td>
			<td><input type="submit" value="Search" class="button" name="submit_btn"></td>
			<td></td>			
		</tr>
		</table>
		
	</form>
<br>
<?php
    if(isset($_REQUEST['submit_btn']))
    {
       echo "<div>";
       $LOTID = $_POST["LOTID"];
       $BINID = $_POST["BINID"];
       $REJECTS = $_POST["REJECTS"];	   
       echo "ANSWER:</br></br>", $LOTID . "<br>" . $BINID . "<br>" . $REJECTS . "<br>";
       echo "</div>";
    }
?>

<table id="myTable">
	<tr>
		<th>PARAMETER</th>
		<th>REFERENCE</th>
		<th>RESULT</th>
	<tr>
	<tr>
		<td>FROM DB</td>
		<td>FROM DB</td>
		<td>FROM DB</td>
	<tr>
	<tr>
		<td>FROM DB</td>
		<td>FROM DB</td>
		<td>FROM DB</td>
	<tr>
</table>
	
</div>
	
</div>


<script src="external/jquery/jquery-3.1.0.js"></script>
<script src="external/jquery/jquery.js"></script>
<script src="external/lib/jquery-ui.js"></script>
<script>
$( "#tabs" ).tabs();
// Hover states on the static widgets
$( "#dialog-link, #icons li" ).hover(
	function() {
		$( this ).addClass( "ui-state-hover" );
	},
	function() {
		$( this ).removeClass( "ui-state-hover" );
	}
);
</script>
<script>
function validate(evt) {
  var theEvent = evt || window.event;

  // Handle paste
  if (theEvent.type === 'paste') {
      key = event.clipboardData.getData('text/plain');
  } else {
  // Handle key press
      var key = theEvent.keyCode || theEvent.which;
      key = String.fromCharCode(key);
  }
  var regex = /[0-9]|\./;
  if( !regex.test(key) ) {
    theEvent.returnValue = false;
    if(theEvent.preventDefault) theEvent.preventDefault();
  }
}
</script>
</body>
</html>