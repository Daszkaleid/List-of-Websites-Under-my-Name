<?php
// Declare variables
	$VAR_REJ=$_POST["REJECTS"];
	$VAR_LOT=$_POST["LOTID"];
	$VAR_BATCH=$_POST["BATCHID"];
	$VAR_BIN=$_POST["BINID"];

//	ECHO $VAR_SELECTION . "<br>" . $VAR_LOT . "<br>" . $VAR_BATCH . "<br>" . $VAR_BIN;
	ECHO $VAR_REJ . "<br>" . $VAR_LOT . "<br>" . $VAR_BIN;
?>