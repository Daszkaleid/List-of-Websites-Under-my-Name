<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="X-UA-Compatible" content="IE=11">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="Content-type" content="text/html; charset=utf-8">
	<meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=no">
	<title>DataTables example - DataTables events</title>
	<link rel="shortcut icon" type="image/png" href="/media/images/favicon.png">
	<link rel="alternate" type="application/rss+xml" title="RSS 2.0" href="http://www.datatables.net/rss.xml">
	<link rel="stylesheet" type="text/css" href="/media/css/site-examples.css?_=19472395a2969da78c8a4c707e72123a">
	<link rel="stylesheet" type="text/css" href="css/jquery.dataTables.min.css">
	<style type="text/css" class="init">
	
	</style>
	<script type="text/javascript" src="/media/js/site.js?_=5e8f232afab336abc1a1b65046a73460"></script>
	<script type="text/javascript" src="/media/js/dynamic.php?comments-page=examples%2Fadvanced_init%2Fdt_events.html" async></script>
	<script type="text/javascript" language="javascript" src="css/jquery-3.3.1.js"></script>
	<script type="text/javascript" language="javascript" src="css/jquery.dataTables.min.js"></script>
	<script type="text/javascript" language="javascript" src="../resources/demo.js"></script>

	<script type="text/javascript" class="init">
	

$(document).ready(function() {
	var eventFired = function ( type ) {
		var n = $('#demo_info')[0];
		//n.innerHTML += '<div>'+type+' event - '+new Date().getTime()+'</div>';
		//n.scrollTop = n.scrollHeight;		
	}

	$('#example')
		.on( 'order.dt',  function () { eventFired( 'Order' ); } )
		.on( 'search.dt', function () { eventFired( 'Search' ); } )
		.on( 'page.dt',   function () { eventFired( 'Page' ); } )
		.DataTable();
} );


	</script>
</head>
<body class="wide comments example">
	<a name="top" id="top"></a>
	<div class="fw-background">
		<div></div>
	</div>
	<div class="fw-container">
		<div class="fw-body">
			<div class="content">
			
	

<?php					

	$servername = "//tnfsoftwaredev:6969/XE";
    $username = "HANDLER_CONTROLLERS";
    $password = "0000";
    $dbname = "HANDLER_CONTROLLERS";

	$objConnect = oci_connect($username, $password, $servername);
	if (!$objConnect) {
		$m = oci_error();
		echo $m['message'], "<br>";
		
		echo "<script>
				alert('CONNECTION - FAILED!');
		</script>";
		oci_close($objConnect);
	} else {

	$stid = oci_parse($objConnect, 'SELECT * FROM TEMP01_HNDCNTRL');
	oci_execute($stid,OCI_DEFAULT);
	
	echo "	<div id='demo_info' class='box'></div>
				<table id='example' class='display'>
				<thead>
						<tr>
							<th>OWNER</th>
							<th>FOLDER NAME</th>
							<th>PROCESS</th>
							<th>EQUIPMENT MODEL</th>
							<th>EQUIPMENT NAME</th>
							<th>ASSET #</th>
							<th>MACHINE ID</th>
							<th>OPERATING SYSTEM</th>
							<th>OBSOLETE OS</th>
							<th>MAC ADDRESS</th>
							<th>NUMBER OF CPU</th>
							<th>HDD SIZE</th>
							<th>BACK UP</th>
							<th>AV SCANNED</th>
							<th>CATEGORY</th>
							<th>MACHINE AGE</th>
							<th>EXTERNAL DEV.</th>
							<th>USB STATUS</th>
							<th>LOCAL CONTACT</th>
						</tr>
				</thead>
		<tbody>
					";
	
	while (($row = oci_fetch_array($stid, OCI_BOTH)) != false) {
		echo "
		<tr><td>" . $row['OWNER'] . "</td>";
		echo "<td>" . $row['FOLDER_NAME'] . "</td>";
		echo "<td>" . $row['PROCESS'] . "</td>";
		echo "<td>" . $row['EQUIPMENT_MODEL'] . "</td>";
		echo "<td>" . $row['EQUIPMENT_NAME'] . "</td>";
		echo "<td>" . $row['ASSET_NUMBER'] . "</td>";
		echo "<td>" . $row['MACHINE_ID'] . "</td>";
		echo "<td>" . $row['OPERATING_SYSTEM'] . "</td>";
		echo "<td>" . $row['OBSOLETE_OS'] . "</td>";
		echo "<td>" . $row['MAC_ADDRESS'] . "</td>";
		echo "<td>" . $row['NUMBEROF_CPU'] . "</td>";
		echo "<td>" . $row['HDD_SIZE'] . "</td>";
		echo "<td>" . $row['BACK_UP'] . "</td>";
		echo "<td>" . $row['AV_SCANNED'] . "</td>";
		echo "<td>" . $row['CATEGORY'] . "</td>";
		echo "<td>" . $row['MACHINE_AGE'] . "</td>";
		echo "<td>" . $row['EXTERNAL_DEVICES'] . "</td>";
		echo "<td>" . $row['USBPORT_STATUS'] . "</td>";
		echo "<td>" . $row['LOCAL_CONTACT'] . " </td></tr>";
	}

	echo "</tbody></table>";
	oci_free_statement($stid);
	oci_close($objConnect);
	
	}
?>				
			

		</div>
	</div>
	<div class="fw-footer">
		<div class="skew"></div>
		<div class="skew-bg"></div>
		<div class="copyright">
		<p>Questions/Suggestion: <a href="http://tnfsoftwaredev/sysadmin/khlouie">Home| OPS1</a>.<br>
			© 2019 <a href="">OPS1 - Mfg Home.TnF</a><br>
			STMicroelectronic - CAL property in Philippines. <br>Developed by: <a href="">249538</a>.</p>
		</div>
	</div>

</body>
</html>