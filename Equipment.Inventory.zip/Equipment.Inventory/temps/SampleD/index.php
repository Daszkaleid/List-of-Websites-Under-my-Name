<?php 
	$servername = "//tnfsoftwaredev:6969/XE";
    $username = "HANDLER_CONTROLLERS";
    $password = "0000";
    $dbname = "HANDLER_CONTROLLERS";

	$objConnect = oci_connect($username, $password, $servername);
	if (!$objConnect) {
		$m = oci_error();
		echo $m['message'], "<br>";
		
		echo "<script>
				alert('CONNECTION - FAILED!');
		</script>";
		oci_close($objConnect);
	}
?>
<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="X-UA-Compatible" content="IE=11">
	<meta http-equiv="Content-type" content="text/html; charset=utf-8">
	<meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=no">
	<title>Responsive integration (Bootstrap)</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/dataTables.bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/fixedHeader.bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/responsive.bootstrap.min.css">
	<script type="text/javascript" language="javascript" src="js/jquery-3.3.1.js"></script>
	<script type="text/javascript" language="javascript" src="js/jquery.dataTables.min.js"></script>
	<script type="text/javascript" language="javascript" src="js/dataTables.bootstrap.min.js"></script>
	<script type="text/javascript" language="javascript" src="js/dataTables.fixedHeader.min.js"></script>
	<script type="text/javascript" language="javascript" src="js/dataTables.responsive.min.js"></script>
	<script type="text/javascript" language="javascript" src="js/responsive.bootstrap.min.js"></script>
	<script type="text/javascript" class="init">
	

$(document).ready(function() {
	var table = $('#example').DataTable( {
		responsive: true
	} );

	new $.fn.dataTable.FixedHeader( table );
} );


	</script>

</head>
<body class="wide comments example dt-example-bootstrap">
<!-- 
 <div class="header-right">
	<input onclick="document.getElementById('id01').style.display='block'" value="sign in" type="submit" class="button">
 </div>
-->
  <br><br><br>

	<a name="top" id="top"></a>
	<div class="fw-background">
		<div></div>
	</div>
	<div class="fw-container">

		<div class="fw-body">
			<div class="content">

<!--			
<div id="id01" class="modal">
  
<form class="modal-content animate" method="post" action="access/validation.php">

	<tr>
		<td>
		<span onclick="document.getElementById('id01').style.display='none'" class="close" title="close">&times;</span>
		<div align="center"><img src="css/keys.png">
		</div>
		</td>
	</tr>
	<tr>
		<td><div align="center"><input align="center" type="text" placeholder="Employee ID" onkeypress='validate(event)' name="uname" required></div></td>
	</tr>
	<tr>
		<td><div align="center"><input align="center" type="password" placeholder="Password" name="psw" required></div></td>
	</tr>
	<tr>
		<td><div align="center"><button type="submit" class="button button4" onclick="return close_window();">Login</button></div></td>
	</tr>
	<tr>
		<td><div align="center"> Remember me
		<label>
        <input type="checkbox" checked="checked" name="remember">
		</label>
		</div></td>
	</tr>

  </form>
</div> -->
			
			<?php					

	$servername = "//tnfsoftwaredev:6969/XE";
    $username = "HANDLER_CONTROLLERS";
    $password = "0000";
    $dbname = "HANDLER_CONTROLLERS";

	$objConnect = oci_connect($username, $password, $servername);
	if (!$objConnect) {
		$m = oci_error();
		echo $m['message'], "<br>";
		
		echo "<script>
				alert('CONNECTION - FAILED!');
		</script>";
		oci_close($objConnect);
	} else {

	$stid = oci_parse($objConnect, 'SELECT * FROM TEMP01_HNDCNTRL');
	oci_execute($stid,OCI_DEFAULT);
	
	echo "	<div id='demo_info' class='box'></div>
				<table id='example' class='table table-striped table-bordered nowrap' style='width:70%'>
				<thead>
						<tr>
							<th>OWNER:</th>
							<th>DIRECTORY:</th>
							<th>PROCESS:</th>
							<th>EQPT.MODEL:</th>
							<th>EQPT.NAME:</th>
							<th>ASSET#:</th>
							<th>MACHINE.ID:</th>
							<th>OS.TYPE:</th>
							<th>OBSOLETE:</th>
							<th>MAC.ADD:</th>
							<th>#.OF.CPU:</th>
							<th>HDD.STORAGE:</th>
							<th>BACK.UP:</th>
							<th>AV.SCAN:</th>
							<th>CATEGORY:</th>
							<th>MACHINE.AGE:</th>
							<th>EXTRNL.DEV:</th>
							<th>USB:STATUS:</th>
							<th>CONTACT.#:</th>
							
							<th>USB.LVL:</th>
							<th>AV.SOFTWARE:</th>
							<th>NO-AV.SOFTWARE:</th>
							<th>SEP:</th>
							<th>IPADD:</th>
							<th>SOFTWARE.VERSION:</th>
							<th>SERIAL#:</th>
							<th>COST.CENTER:</th>
							<th>SUPPLIER:</th>
							<th>LOCAL#:</th>
							<th>CREATED:</th>
							<th>UPDATE:</th>
							<th>REVISED:</th>
							
						</tr>
				</thead>
		<tbody>
					";
	
	while (($row = oci_fetch_array($stid, OCI_RETURN_NULLS+OCI_ASSOC)) != false) {
		echo '<tr>';
			foreach ($row as $item) {
				echo '<td>'.($item?htmlentities($item):' ').'</td>';
			}
		echo '</tr>';		
		
	}

	echo "</tbody></table>";
	oci_free_statement($stid);
	oci_close($objConnect);
	
	}
?>	
			
<!--				<table id="example" class="table table-striped table-bordered nowrap" style="width:100%">

				</table>-->
			</div>
		</div>
	</div>
	<div class="fw-footer">
		<div class="skew"></div>
		<div class="skew-bg"></div>
		<div class="copyright">
		© 2019 OPS1 - Mfg Home.TnF
		<br>
		STMicroelectronic - CAL property in Philippines. <br>Developed by: 249538</p>
		</div>
	</div>
</body>
</html>