
<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="X-UA-Compatible" content="IE=11">
	<meta http-equiv="Content-type" content="text/html; charset=utf-8">
	<meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=no">
	<title>DataTables example - Responsive integration (Bootstrap)</title>
	<link rel="shortcut icon" type="image/png" href="/media/images/favicon.png">
	<link rel="alternate" type="application/rss+xml" title="RSS 2.0" href="http://www.datatables.net/rss.xml">
	<link rel="stylesheet" type="text/css" href="/media/css/site-examples.css?_=19472395a2969da78c8a4c707e72123a">
	<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/fixedheader/3.1.5/css/fixedHeader.bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/responsive/2.2.3/css/responsive.bootstrap.min.css">
	<style type="text/css" class="init">
	
	</style>
	<script type="text/javascript" src="/media/js/site.js?_=5e8f232afab336abc1a1b65046a73460"></script>
	<script type="text/javascript" src="/media/js/dynamic.php?comments-page=extensions%2Ffixedheader%2Fexamples%2Fintegration%2Fresponsive-bootstrap.html" async></script>
	<script type="text/javascript" language="javascript" src="https://code.jquery.com/jquery-3.3.1.js"></script>
	<script type="text/javascript" language="javascript" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
	<script type="text/javascript" language="javascript" src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap.min.js"></script>
	<script type="text/javascript" language="javascript" src="https://cdn.datatables.net/fixedheader/3.1.5/js/dataTables.fixedHeader.min.js"></script>
	<script type="text/javascript" language="javascript" src="https://cdn.datatables.net/responsive/2.2.3/js/dataTables.responsive.min.js"></script>
	<script type="text/javascript" language="javascript" src="https://cdn.datatables.net/responsive/2.2.3/js/responsive.bootstrap.min.js"></script>
	<script type="text/javascript" language="javascript" src="../../../../examples/resources/demo.js"></script>
	<script type="text/javascript" class="init">
	

$(document).ready(function() {
	var table = $('#example').DataTable( {
		responsive: true
	} );

	new $.fn.dataTable.FixedHeader( table );
} );


	</script>
</head>
<body class="wide comments example dt-example-bootstrap">
	<a name="top" id="top"></a>
	<div class="fw-background">
		<div></div>
	</div>
	<div class="fw-container">

		<div class="fw-body">
		<div class="content">
			<br><br><br><br><br>

<?php					

	$servername = "//tnfsoftwaredev:6969/XE";
    $username = "HANDLER_CONTROLLERS";
    $password = "0000";
    $dbname = "HANDLER_CONTROLLERS";

	$objConnect = oci_connect($username, $password, $servername);
	if (!$objConnect) {
		$m = oci_error();
		echo $m['message'], "<br>";
		
		echo "<script>
				alert('CONNECTION - FAILED!');
		</script>";
		oci_close($objConnect);
	} else {

	$stid = oci_parse($objConnect, 'SELECT DISTINCT * FROM TEMP01_HNDCNTRL');
	oci_execute($stid,OCI_DEFAULT);
	
	echo "	<div id='demo_info' class='box'></div>
				<table id='example' class='display'>
				<thead>
						<tr>
							<th>OWNER:</th>
							<th>FOLDER:</th>
							<th>PROCESS:</th>
							<th>EQUIPMENT.MODEL:</th>
							<th>EQUIPMENT.NAME:</th>
							<th>ASSET.#:</th>
							<th>MACHINE.ID:</th>
							<th>OS:</th>
							<th>OBSOLETE.OS:</th>
							<th>MAC.ADDRESS:</th>
							<th>#OFCPU:</th>
							<th>HDD.SIZE:</th>
							<th>BACK.UP:</th>
							<th>AV.SCANNED:</th>
							<th>CATEGORY:</th>
							<th>MACHINE.AGE:</th>
							<th>EXT.DEV.:</th>
							<th>USB.STATUS:</th>
							
							<th>USB.LVL:</th>
							<th>AV.SOFTWARE:</th>
							<th>IFNOAV.SOFTWARE:</th>
							<th>SEP:</th>
							<th>IPADD:</th>
							<th>IFNOAV.SOFTWARE:</th>
							<th>SOFTWARE.VERSION:</th>
							<th>SERIAL#:</th>
							<th>CC:</th>
							<th>SUPPLIER.LABEL:</th>
							<th>CONTACT#:</th>
							<th>CREATED:</th>
							<th>UPDATE.LOG:</th>
							<th>REV.LOG:</th>
							
							
						</tr>
				</thead>
		<tbody>
					";
	
	while (($row = oci_fetch_array($stid, OCI_RETURN_NULLS+OCI_ASSOC)) != false) {
		print '<tr>';
			foreach ($row as $item) {
				print '<td>'.($item?htmlentities($item):' ').'</td>';
			}
		print '</tr>';
	}

	echo "</tbody></table>";
	oci_free_statement($stid);
	oci_close($objConnect);
	
	}
?>		
			
		</div>
	</div>
	<div class="fw-footer">
		<div class="skew"></div>
		<div class="skew-bg"></div>
		<div class="copyright">
		© 2019 OPS1 - Mfg Home.TnF
		<br>
		STMicroelectronic - CAL property in Philippines. <br>Developed by: <a href="">249538</a>.</p>
		</div>
	</div>

</body>
</html>