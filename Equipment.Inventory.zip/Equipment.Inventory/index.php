<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="X-UA-Compatible" content="IE=11">
	<meta name="viewport" content="width=device-width, initial-scale=1">
    <title>T&F| Equipment Inventory</title>
    <link rel="stylesheet" type="text/css" href="css/demos.css" />
	<link rel="icon" href="css/icon.ico" type="image/x-icon">
    <script src="external/jquery/jquery-1.8.3.js"></script>

<script type="text/javascript">
$(document).ready(function () {
    if(window.location.href.indexOf("index.php") > -1) {
	   window.location.href='http://tnfsoftwaredev/sysadmin/SoftwareDev_Applications/iCOS_AutoSetup/';
    }
});
</script>
<SCRIPT TYPE="text/javascript">

<!--
//Disable right click script
var message="Sorry, right-click has been disabled";
///////////////////////////////////
function clickIE() {if (document.all) {(message);return false;}}
function clickNS(e) {if
(document.layers||(document.getElementById&&!document.all)) {
if (e.which==2||e.which==3) {(message);return false;}}}
if (document.layers)
{document.captureEvents(Event.MOUSEDOWN);document.onmousedown=clickNS;}
else{document.onmouseup=clickNS;document.oncontextmenu=clickIE;}
document.oncontextmenu=new Function("return false")
// -->
</SCRIPT>
<SCRIPT>
$(document).keydown(function (event) {
    if (event.keyCode == 123) { // Prevent F12
        return false;
    } else if (event.ctrlKey && event.shiftKey && event.keyCode == 73) { // Prevent Ctrl+Shift+I        
        return false;
    }
});
</SCRIPT>
<style>
.wrapper_tag_A1 {
    min-height: 80%;
    height: auto;
    margin: 0 auto -4em;
}
.footer_tag_A1 {
    clear: both;
    position: relative;
    height: auto;

}
</style>

</head>
<body>
<!-- Ref: <h3 style="background-color:white; padding:2% 0 2% 0; border-top:2px solid grey; border-bottom: 2px solid grey;"> -->
	<h3 style="background-color:white; padding:2% 0 2% 0; border-top:10px solid grey;">
		<div>
			<img src="images/equipment.ent.png" alt="logo"/>
		</div>
	</h3>

		<div class="wrapper_tag_A1">
            <br/>
			<p>Your website content here.</p>
			
        </div>


        <div class="footer_tag_A1">
			<h3 style="background-color:white; padding:2% 0 2% 0; border-bottom: 10px solid grey;">
				<div>
					<p>Developer ID#: 249538</p>
				</div>
			</h3>
        </div>



<table align="center">
<tr align="center">

</tr>
</table>










</body>
</html>